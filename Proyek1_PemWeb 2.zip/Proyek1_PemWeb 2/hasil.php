<?php
 include_once 'headerp3.php';
?>

<h1>Welcome Home !!! </h1>

<?php
 require_once 'footerp3.php';
?>